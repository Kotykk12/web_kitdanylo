export const environment = {
    production: true,
    apiUrl: 'https://yourdomain.com/api' // Your production server address
  };